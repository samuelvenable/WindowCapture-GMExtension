#include <windows.h>
#include <iostream>
#include <string>
#include <vector>

std::wstring widen(std::string str) {
  if (str.empty()) return L"";
  std::size_t wchar_count = str.size() + 1;
  std::vector<wchar_t> buf(wchar_count);
  return std::wstring{ buf.data(), (std::size_t)MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, buf.data(), (int)wchar_count) };
}

void CaptureClientArea(HWND hwnd, const char *filename) {
  HDC hdcWindow = GetDC(hwnd);
  HDC hdcMemDC = CreateCompatibleDC(hdcWindow);
  if (!hdcMemDC) {
    std::cerr << "Failed to create compatible DC!" << std::endl;
    ReleaseDC(hwnd, hdcWindow);
    return;
  }
  RECT clientRect;
  GetClientRect(hwnd, &clientRect);
  int width = clientRect.right - clientRect.left;
  int height = clientRect.bottom - clientRect.top;
  HBITMAP hbmScreen = CreateCompatibleBitmap(hdcWindow, width, height);
  if (!hbmScreen) {
    std::cerr << "Failed to create compatible bitmap!" << std::endl;
    DeleteDC(hdcMemDC);
    ReleaseDC(hwnd, hdcWindow);
    return;
  }
  SelectObject(hdcMemDC, hbmScreen);
  if (!BitBlt(hdcMemDC, 0, 0, width, height, hdcWindow, 0, 0, SRCCOPY)) {
    std::cerr << "BitBlt failed!" << std::endl;
  } else {
    std::cout << "Client area captured successfully!" << std::endl;
  }
  BITMAP bmpScreen;
  DWORD dwBytesWritten = 0;
  DWORD dwSizeofDIB = 0;
  HANDLE hFile = nullptr;
  char *lpbitmap = nullptr;
  HANDLE hDIB = nullptr;
  DWORD dwBmpSize = 0;
  GetObject(hbmScreen, sizeof(BITMAP), &bmpScreen);
  BITMAPFILEHEADER   bmfHeader;
  BITMAPINFOHEADER   bi;
  bi.biSize = sizeof(BITMAPINFOHEADER);
  bi.biWidth = bmpScreen.bmWidth;
  bi.biHeight = bmpScreen.bmHeight;
  bi.biPlanes = 1;
  bi.biBitCount = 32;
  bi.biCompression = BI_RGB;
  bi.biSizeImage = 0;
  bi.biXPelsPerMeter = 0;
  bi.biYPelsPerMeter = 0;
  bi.biClrUsed = 0;
  bi.biClrImportant = 0;
  dwBmpSize = ((bmpScreen.bmWidth * bi.biBitCount + 31) / 32) * 4 * bmpScreen.bmHeight;
  hDIB = GlobalAlloc(GHND, dwBmpSize);
  lpbitmap = (char *)GlobalLock(hDIB);
  GetDIBits(hdcWindow, hbmScreen, 0, (UINT)bmpScreen.bmHeight, lpbitmap, (BITMAPINFO *)&bi, DIB_RGB_COLORS);
  std::wstring wfilename = widen(filename);
  hFile = CreateFileW(wfilename.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
  dwSizeofDIB = dwBmpSize + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
  bmfHeader.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + (DWORD)sizeof(BITMAPINFOHEADER);
  bmfHeader.bfSize = dwSizeofDIB;
  bmfHeader.bfType = 0x4D42;
  WriteFile(hFile, (LPSTR)&bmfHeader, sizeof(BITMAPFILEHEADER), &dwBytesWritten, nullptr);
  WriteFile(hFile, (LPSTR)&bi, sizeof(BITMAPINFOHEADER), &dwBytesWritten, nullptr);
  WriteFile(hFile, (LPSTR)lpbitmap, dwBmpSize, &dwBytesWritten, nullptr);
  GlobalUnlock(hDIB);
  GlobalFree(hDIB);
  CloseHandle(hFile);
  DeleteObject(hbmScreen);
  DeleteDC(hdcMemDC);
  ReleaseDC(hwnd, hdcWindow);
}

int main(int argc, char **argv) {
  if (argc < 3) {
    std::cout << "usage: wincapt window bitmap" << std::endl;
    return 0;
  }
  HWND hwnd = (HWND)(void *)strtoll(argv[1], nullptr, 10);
  if (!hwnd || !IsWindow(hwnd)) {
    std::cerr << "Window not found!" << std::endl;
    return 1;
  }
  CaptureClientArea(hwnd, argv[2]);
  return 0;
}
