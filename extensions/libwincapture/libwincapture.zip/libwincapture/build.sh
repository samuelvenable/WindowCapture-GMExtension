#!/bin/sh
cd "${0%/*}"
cd "src"

if [ $(uname) = "Darwin" ]; then
  clang++ libwincapture.cpp gamemaker.cpp -I../include/ -o ../libwincapture.dylib -std=c++17 -shared -framework AppKit -framework CoreGraphics
elif [ $(uname) = "Linux" ]; then
  g++ libwincapture.cpp gamemaker.cpp -I../include/ -o ../libwincapture.so -std=c++17 -shared -static-libgcc -static-libstdc++ -lX11
fi
