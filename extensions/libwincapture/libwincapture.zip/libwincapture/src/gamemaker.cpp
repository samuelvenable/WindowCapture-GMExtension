#include "libwincapture.h"

#ifdef _WIN32
#define EXPORTED_FUNCTION extern "C" __declspec(dllexport)
#else /* macOS and Linux */
#define EXPORTED_FUNCTION extern "C" __attribute__((visibility("default")))
#endif

EXPORTED_FUNCTION double capture_add(char *window) {
  return libwincapture::capture_add(window);
}

EXPORTED_FUNCTION double capture_exists(double ind) {
  return libwincapture::capture_exists((int)ind);
}

EXPORTED_FUNCTION double capture_delete(double ind) {
  return libwincapture::capture_delete((int)ind);
}

EXPORTED_FUNCTION double capture_get_showcursor(double ind) {
  return libwincapture::capture_get_showcursor((int)ind);
}

EXPORTED_FUNCTION double capture_set_showcursor(double ind, double show) {
  return libwincapture::capture_set_showcursor((int)ind, (bool)show);
}

EXPORTED_FUNCTION double capture_get_width(double ind) {
  return libwincapture::capture_get_width((int)ind);
}

EXPORTED_FUNCTION double capture_get_height(double ind) {
  return libwincapture::capture_get_height((int)ind);
}

EXPORTED_FUNCTION double capture_grab_frame_buffer(double ind, char *buffer) {
  return libwincapture::capture_grab_frame_buffer((int)ind, (unsigned char *)buffer);
}
