#include "libwincapture.h"

#ifdef _WIN32
#define EXPORTED_FUNCTION extern "C" __declspec(dllexport)
#else /* macOS, Linux, and BSD */
#define EXPORTED_FUNCTION extern "C" __attribute__((visibility("default")))
#endif

EXPORTED_FUNCTION double capture_add(char *window) {
  return libwincapture::capture_add(window);
}

EXPORTED_FUNCTION double capture_exists(double ind) {
  return libwincapture::capture_exists((int)ind);
}

EXPORTED_FUNCTION double capture_delete(double ind) {
  return libwincapture::capture_delete((int)ind);
}

EXPORTED_FUNCTION double capture_get_width(double ind) {
  return libwincapture::capture_get_width((int)ind);
}

EXPORTED_FUNCTION double capture_get_height(double ind) {
  return libwincapture::capture_get_height((int)ind);
}

EXPORTED_FUNCTION double capture_grab_frame_buffer(double ind, char *buffer) {
  return libwincapture::capture_grab_frame_buffer((int)ind, (void *)buffer);
}

EXPORTED_FUNCTION double capture_update(double ind) {
  return libwincapture::capture_update((int)ind);
}

EXPORTED_FUNCTION double capture_create_window_list() {
  return libwincapture::capture_create_window_list();
}

EXPORTED_FUNCTION double capture_window_list_exists(double list) {
  return libwincapture::capture_window_list_exists((int)list);
}

EXPORTED_FUNCTION char *capture_get_window_id(double list, double ind) {
  static std::string result;
  result = libwincapture::capture_get_window_id((int)list, (int)ind);
  return (char *)result.c_str();
}

EXPORTED_FUNCTION double capture_get_window_id_length(double list) {
  return libwincapture::capture_get_window_id_length((int)list);
}

EXPORTED_FUNCTION double capture_destroy_window_list(double list) {
  return libwincapture::capture_destroy_window_list((int)list);
}

EXPORTED_FUNCTION char *capture_get_window_caption(char *window) {
  static std::string result;
  result = libwincapture::capture_get_window_caption(window);
  return (char *)result.c_str();
}

EXPORTED_FUNCTION double capture_get_fixedsize(double ind) {
  return libwincapture::capture_get_fixedsize((int)ind);
}

EXPORTED_FUNCTION double capture_set_fixedsize(double ind, double fixed) {
  return libwincapture::capture_set_fixedsize((int)ind, (bool)fixed);
}

EXPORTED_FUNCTION double capture_monitor_get_count() {
  return libwincapture::capture_monitor_get_count();
}

EXPORTED_FUNCTION double capture_monitor_get_current() {
  return libwincapture::capture_monitor_get_current();
}

EXPORTED_FUNCTION double capture_monitor_set_current(double current) {
  libwincapture::capture_monitor_set_current((int)current);
  return 0;
}

EXPORTED_FUNCTION const char *capture_monitor_get_name() {
  static std::string result;
  result = libwincapture::capture_monitor_get_name();
  return result.c_str();
}

EXPORTED_FUNCTION double capture_monitor_init_info() {
  libwincapture::capture_monitor_init_info();
  return 0;
}
