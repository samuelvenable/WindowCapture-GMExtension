#include <string>
#include <vector>
#include <memory>
#include <unordered_map>

#include "libwincapture.h"

#if defined(_WIN32)
#include <windows.h>
#elif (defined(__APPLE__) && defined(__MACH__))
#include <AppKit/AppKit.h>
#include <CoreGraphics/CoreGraphics.h>
#elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
#include <X11/Xlib.h>
#endif

#if defined(_WIN32)
#define native_window_t HWND
#elif ((defined(__APPLE__) && defined(__MACH__))
#define native_window_t NSWindow *
#elif (defined(__linux__) && !defined(__ANDROID__)) || (defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__)) || defined(__sun)
#define native_window_t Window
#endif
#define window_t char *

namespace {

int index = -1;
int windex = -1;
std::unordered_map<int, window_t>   capture_window;
std::unordered_map<int, int>        capture_width;
std::unordered_map<int, int>        capture_height;
std::unordered_map<int, window_t *> window_list;
std::unordered_map<int, int>        window_list_length;

#if defined(_WIN32)
std::string narrow(std::wstring wstr) {
  if (wstr.empty()) return "";
  int nbytes = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), (int)wstr.length(), nullptr, 0, nullptr, nullptr);
  std::vector<char> buf(nbytes);
  return std::string { buf.data(), (std::size_t)WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), (int)wstr.length(), buf.data(), nbytes, nullptr, nullptr) };
}

void RgbToRgba(const unsigned char *RGB, unsigned char **RGBA, int width, int height) {
  for (int y = 0; y < height; y++) {
    if (y > height) break;
    for (int x = 0; x < width; x++) {
      if (x > width) break;
      (*RGBA)[(y * width + x) * 4 + 0] = RGB[(y * width + x) * 3 + 2];
      (*RGBA)[(y * width + x) * 4 + 1] = RGB[(y * width + x) * 3 + 1];
      (*RGBA)[(y * width + x) * 4 + 2] = RGB[(y * width + x) * 3 + 0];
      (*RGBA)[(y * width + x) * 4 + 3] = 255;
    }
  }
}

void CaptureWindow(HWND hwndTarget, unsigned char **pixels, int *width, int *height) {
  (*width) = -1;
  (*height) = -1;
  if (!IsWindow(hwndTarget)) return; 
  RECT rect; GetClientRect(hwndTarget, &rect);
  if ((rect.right - rect.left) > 16384 || (rect.bottom - rect.top) > 16384) return;
  (*width) = (rect.right - rect.left);
  (*height) = (rect.bottom - rect.top);
  if (pixels) {
    HDC hdcWindow = GetDC(hwndTarget);
    HDC hdcMemDC = CreateCompatibleDC(hdcWindow);
    if (!hdcMemDC) {
      ReleaseDC(hwndTarget, hdcWindow);
      return;
    }
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcWindow, (*width), (*height));
    if (!hbmScreen) {
      DeleteDC(hdcMemDC);
      ReleaseDC(hwndTarget, hdcWindow);
      return;
    }
    SelectObject(hdcMemDC, hbmScreen);
    if (!BitBlt(hdcMemDC, 0, 0, (*width), (*height), hdcWindow, 0, 0, SRCCOPY)) {
      return;
    }
    BITMAPINFO bmpInfo;
    bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmpInfo.bmiHeader.biWidth = (*width);
    bmpInfo.bmiHeader.biHeight = -(*height);
    bmpInfo.bmiHeader.biPlanes = 1;
    bmpInfo.bmiHeader.biBitCount = 24;
    bmpInfo.bmiHeader.biCompression = BI_RGB;
    std::vector<unsigned char> src((*width) * (*height) * 3);
    if (!GetDIBits(hdcMemDC, hbmScreen, 0, (*height), src.data(), &bmpInfo, DIB_RGB_COLORS)) {
      return;
    }
    RgbToRgba(src.data(), pixels, (*width), (*height));
    DeleteObject(hbmScreen);
    DeleteDC(hdcMemDC);
    ReleaseDC(hwndTarget, hdcWindow);
  }
}
#endif

  #if ((defined(__linux__) && !defined(__ANDROID__)) || (defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__)) || defined(__sun))
  static inline int x_error_handler_impl(Display *display, XErrorEvent *event) {
    return 0;
  }

  static inline int x_io_error_handler_impl(Display *display) {
    return 0;
  }

  static inline void set_error_handlers() {
    XSetErrorHandler(x_error_handler_impl);
    XSetIOErrorHandler(x_io_error_handler_impl);
  }
  #endif

  window_t WindowIdFromNativeWindow(native_window_t window) {
    static std::string res;
    #if (defined(__APPLE__) && defined(__MACH__))
    res = std::to_string((unsigned long long)(void *)[(NSWindow *)window windowNumber]);
    #else
    res = std::to_string((unsigned long long)(void *)window);
    #endif
    return (window_t)res.c_str();
  }

  native_window_t NativeWindowFromWindowd(window_t winId) {
    #if (defined(__APPLE__) && defined(__MACH__))
    return (native_window_t)(void *)[NSApp windowWithWindowNumber:(CGWindowID)strtoul(winId, nullptr, 10)];
    #else
    return (native_window_t)(void *)strtoull(winId, nullptr, 10);
    #endif
  }

  void WindowIdEnumerate(window_t **winId, int *size) {
    static std::vector<std::string> widVec1;
    *winId = nullptr; *size = 0;
    widVec1.clear();
    #if defined(_WIN32)
    HWND hWnd = GetTopWindow(GetDesktopWindow());
    if (IsWindowVisible(hWnd)) widVec1.push_back(WindowIdFromNativeWindow((native_window_t)hWnd));
    while (hWnd = GetWindow(hWnd, GW_HWNDNEXT)) {
      if (IsWindowVisible(hWnd)) widVec1.push_back(WindowIdFromNativeWindow((native_window_t)hWnd));
    }
    #elif (defined(__APPLE__) && defined(__MACH__)) && !defined(PROCESS_XQUARTZ_IMPL)
    #elif (defined(__linux__) && !defined(__ANDROID__)) || (defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__)) || defined(__sun) || defined(PROCESS_XQUARTZ_IMPL)
    #endif
    std::vector<window_t> widVec2;
    for (std::size_t i = 0; i < widVec1.size(); i++) {
      widVec2.push_back((window_t)widVec1[i].c_str());
    }
    window_t *arr = new window_t[widVec2.size()]();
    std::copy(widVec2.begin(), widVec2.end(), arr);
    *winId = arr; *size = (int)widVec2.size();
  }

  bool WindowIdFree(window_t *winId) {
    if (winId) {
      delete[] winId;
      return true;
    }
    return false;
  }

} // anonymous namespace

namespace libwincapture {

int capture_add(window_t window) {
  index++;
  capture_window[index] = window;
  #if defined(_WIN32)
  CaptureWindow((HWND)(void *)window, nullptr, &capture_width[index], &capture_height[index]);
  #elif (defined(__APPLE__) && defined(__MACH__))
  #elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
  #endif
  return index;
}

bool capture_exists(int ind) {
  if (capture_window.find(ind) == capture_window.end()) return false;
  return true;
}

bool capture_delete(int ind) {
  if (!capture_exists(ind)) return false;
  capture_window.erase(ind);
  capture_width.erase(ind);
  capture_height.erase(ind);
  return true;
}

int capture_get_width(int ind) {
  if (!capture_exists(ind)) return -1;
  return capture_width.find(ind)->second;
}

int capture_get_height(int ind) {
  if (!capture_exists(ind)) return -1;
  return capture_height.find(ind)->second;
}

bool capture_grab_frame_buffer(int ind, unsigned char *buffer) {
  if (!capture_exists(ind)) return false;
  #if defined(_WIN32)
  HWND hwnd = (HWND)(void *)capture_window.find(ind)->second;
  unsigned char *pixels = buffer;
  CaptureWindow(hwnd, &pixels, &capture_width[ind], &capture_height[ind]);
  #elif (defined(__APPLE__) && defined(__MACH__))
  #elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
  #endif
  return true;
}

bool capture_update(int ind) {
  if (!capture_exists(ind)) return false;
  #if defined(_WIN32)
  HWND hwnd = (HWND)(void *)capture_window.find(ind)->second;
  CaptureWindow(hwnd, nullptr, &capture_width[ind], &capture_height[ind]);
  #elif (defined(__APPLE__) && defined(__MACH__))
  #elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
  #endif
  return true;
}

int capture_create_window_list() {
  windex++;
  WindowIdEnumerate(&window_list[windex], &window_list_length[windex]);
  return windex;
}

window_t capture_get_window_id(int list, int ind) {
  return window_list[list][ind];
}

int capture_get_window_id_length(int list) {
  return window_list_length[list];
}

bool capture_destroy_window_list(int list) {
  return WindowIdFree(window_list[list]);
}

char *capture_get_window_caption(window_t window) {
  HWND hWnd = NativeWindowFromWindowd(window);
  std::size_t length = GetWindowTextLengthW(hWnd) + 1;
  wchar_t *buffer = new wchar_t[length]();
  if (GetWindowTextW(hWnd, buffer, length)) {
    static std::string str;
    str = narrow(buffer);
    return (char *)str.c_str();
  }
  return (char *)"";
}

} // namespace libwincapture

