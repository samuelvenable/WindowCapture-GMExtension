#include <string>
#include <vector>
#include <memory>
#include <unordered_map>

#include "libwincapture.h"

#if defined(_WIN32)
#include <windows.h>
#include <dxgi.h>
#include <inspectable.h>
#include <dxgi1_2.h>
#include <d3d11.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.System.h>
#include <winrt/Windows.Graphics.Capture.h>
#include <windows.graphics.capture.interop.h>
#include <windows.graphics.directx.direct3d11.interop.h>
#include <dwmapi.h>
#elif (defined(__APPLE__) && defined(__MACH__))
#include <CoreGraphics/CoreGraphics.h>
#elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
#include <X11/Xlib.h>
#endif

#if defined(_WIN32)
#pragma comment(lib,"Dwmapi.lib")
#pragma comment(lib,"windowsapp.lib")
#endif

namespace {

#if defined(_WIN32)
void CaptureWindow(HWND hwndTarget, unsigned char **pixels, int *width, int *height) {
  winrt::com_ptr<ID3D11Device> d3dDevice;
  winrt::check_hresult(D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
  nullptr, 0,D3D11_SDK_VERSION, d3dDevice.put(), nullptr, nullptr));
  winrt::Windows::Graphics::DirectX::Direct3D11::IDirect3DDevice device;
  const auto dxgiDevice = d3dDevice.as<IDXGIDevice>(); {
    winrt::com_ptr<::IInspectable> inspectable;
    winrt::check_hresult(CreateDirect3D11DeviceFromDXGIDevice(dxgiDevice.get(), inspectable.put()));
    device = inspectable.as<winrt::Windows::Graphics::DirectX::Direct3D11::IDirect3DDevice>();
  }
  auto idxgiDevice2 = dxgiDevice.as<IDXGIDevice2>();
  winrt::com_ptr<IDXGIAdapter> adapter;
  winrt::check_hresult(idxgiDevice2->GetParent(winrt::guid_of<IDXGIAdapter>(), adapter.put_void()));
  winrt::com_ptr<IDXGIFactory2> factory;
  winrt::check_hresult(adapter->GetParent(winrt::guid_of<IDXGIFactory2>(), factory.put_void()));
  ID3D11DeviceContext *d3dContext = nullptr;
  d3dDevice->GetImmediateContext(&d3dContext);
  RECT rect;
  DwmGetWindowAttribute(hwndTarget, DWMWA_EXTENDED_FRAME_BOUNDS, &rect, sizeof(RECT));
  const auto size = winrt::Windows::Graphics::SizeInt32{rect.right - rect.left, rect.bottom - rect.top};
  winrt::Windows::Graphics::Capture::Direct3D11CaptureFramePool m_framePool =
  winrt::Windows::Graphics::Capture::Direct3D11CaptureFramePool::Create(device,
  winrt::Windows::Graphics::DirectX::DirectXPixelFormat::R8G8B8A8UIntNormalized, 2, size);
  const auto activationFactory = winrt::get_activation_factory<
  winrt::Windows::Graphics::Capture::GraphicsCaptureItem>();
  auto interopFactory = activationFactory.as<IGraphicsCaptureItemInterop>();
  winrt::Windows::Graphics::Capture::GraphicsCaptureItem captureItem = {nullptr};
  interopFactory->CreateForWindow(hwndTarget, winrt::guid_of<ABI::Windows::Graphics::Capture::IGraphicsCaptureItem>(),
  reinterpret_cast<void**>(winrt::put_abi(captureItem)));
  auto isFrameArrived = false;
  winrt::com_ptr<ID3D11Texture2D> texture;
  const auto session = m_framePool.CreateCaptureSession(captureItem);
  m_framePool.FrameArrived([&](auto& framePool, auto&) {
    if (isFrameArrived) return;
    auto frame = framePool.TryGetNextFrame();
    struct __declspec(uuid("A9B3D012-3DF2-4EE3-B8D1-8695F457D3C1"))
    IDirect3DDxgiInterfaceAccess : ::IUnknown {
      virtual HRESULT __stdcall GetInterface(GUID const& id, void **object) = 0;
    };
    auto access = frame.Surface().as<IDirect3DDxgiInterfaceAccess>();
    access->GetInterface(winrt::guid_of<ID3D11Texture2D>(), texture.put_void());
    isFrameArrived = true;
  });
  session.IsCursorCaptureEnabled(false);
  session.StartCapture();
  MSG msg;
  clock_t timer = clock();
  while (!isFrameArrived) {
    if (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE) > 0)
      DispatchMessage(&msg);
    if (clock() - timer > 20000) {
      return;
    }
  }
  session.Close();
  D3D11_TEXTURE2D_DESC capturedTextureDesc;
  texture->GetDesc(&capturedTextureDesc);
  capturedTextureDesc.Usage = D3D11_USAGE_STAGING;
  capturedTextureDesc.BindFlags = 0;
  capturedTextureDesc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
  capturedTextureDesc.MiscFlags = 0;
  winrt::com_ptr<ID3D11Texture2D> userTexture = nullptr;
  winrt::check_hresult(d3dDevice->CreateTexture2D(&capturedTextureDesc, nullptr, userTexture.put()));
  d3dContext->CopyResource(userTexture.get(), texture.get());
  D3D11_MAPPED_SUBRESOURCE resource;
  winrt::check_hresult(d3dContext->Map(userTexture.get(), 0, D3D11_MAP_READ, 0, &resource));
  (*width) = capturedTextureDesc.Width;
  (*height) = capturedTextureDesc.Height;
  if (pixels) {
    uint8_t *src = static_cast<uint8_t *>(resource.pData);
    for (int i = 0; i < (*height); i++) {
      memcpy((*pixels), src, (*width) * 4);
      src += resource.RowPitch;
      (*pixels) += ((*width) << 2);
    }
  }
}
#endif

int id = -1;
std::unordered_map<int, window_t> capture_window;
std::unordered_map<int, int> capture_width;
std::unordered_map<int, int> capture_height;

} // anonymous namespace

namespace libwincapture {

int capture_add(window_t window) {
  id++;
  capture_window[id] = window;
  #if defined(_WIN32)
  if (IsWindow((HWND)(void *)window)) CaptureWindow((HWND)(void *)window, nullptr, &capture_width[id], &capture_height[id]);
  #elif (defined(__APPLE__) && defined(__MACH__))
  #elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
  #endif
  return id;
}

bool capture_exists(int ind) {
  if (capture_window.find(ind) == capture_window.end()) return false;
  return true;
}

bool capture_delete(int ind) {
  if (!capture_exists(ind)) return false;
  capture_window.erase(ind);
  capture_width.erase(ind);
  capture_height.erase(ind);
  return true;
}

int capture_get_width(int ind) {
  if (!capture_exists(ind)) return -1;
  return capture_width.find(ind)->second;
}

int capture_get_height(int ind) {
  if (!capture_exists(ind)) return -1;
  return capture_height.find(ind)->second;
}

bool capture_grab_frame_buffer(int ind, unsigned char *buffer) {
  if (!capture_exists(ind)) return false;
  #if defined(_WIN32)
  HWND hwnd = (HWND)(void *)capture_window.find(ind)->second;
  unsigned char *pixels = buffer;
  if (IsWindow(hwnd)) { 
    CaptureWindow(hwnd, &pixels, &capture_width[ind], &capture_height[ind]);
    if (pixels) {
      return true;
    }
  }
  #elif (defined(__APPLE__) && defined(__MACH__))
  #elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
  #endif
  return false;
}

} // namespace libwincapture

