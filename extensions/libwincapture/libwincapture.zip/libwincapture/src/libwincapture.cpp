#include <string>
#include <vector>
#include <memory>
#include <unordered_map>

#include "libwincapture.h"

#if defined(_WIN32)
#include <windows.h>
#elif (defined(__APPLE__) && defined(__MACH__))
#include <CoreGraphics/CoreGraphics.h>
#elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
#include <X11/Xlib.h>
#endif

#if defined(_WIN32)
#pragma comment(lib,"Dwmapi.lib")
#pragma comment(lib,"windowsapp.lib")
#endif

namespace {

int index = -1;
std::unordered_map<int, window_t> capture_window;
std::unordered_map<int, bool>     capture_cursor;
std::unordered_map<int, int>      capture_width;
std::unordered_map<int, int>      capture_height;

#if defined(_WIN32)
void RgbToRgba(const unsigned char *RGB, unsigned char **RGBA, int width, int height) {
  for (int y = 0; y < height; y++) {
    if (y > height) break;
    for (int x = 0; x < width; x++) {
      if (x > width) break;
      (*RGBA)[(y * width + x) * 4 + 0] = RGB[(y * width + x) * 3 + 2];
      (*RGBA)[(y * width + x) * 4 + 1] = RGB[(y * width + x) * 3 + 1];
      (*RGBA)[(y * width + x) * 4 + 2] = RGB[(y * width + x) * 3 + 0];
      (*RGBA)[(y * width + x) * 4 + 3] = 255;
    }
  }
}

void CaptureWindow(int ind, HWND hwndTarget, unsigned char **pixels, int *width, int *height) {
  (*width) = -1;
  (*height) = -1;
  if (!IsWindow(hwndTarget)) return; 
  RECT rect; GetClientRect(hwndTarget, &rect);
  if ((rect.right - rect.left) > 16384 || (rect.bottom - rect.top) > 16384) return;
  (*width) = (rect.right - rect.left);
  (*height) = (rect.bottom - rect.top);
  if (pixels) {
    HDC hdcWindow = GetDC(hwndTarget);
    HDC hdcMemDC = CreateCompatibleDC(hdcWindow);
    if (!hdcMemDC) {
      ReleaseDC(hwndTarget, hdcWindow);
      return;
    }
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcWindow, (*width), (*height));
    if (!hbmScreen) {
      DeleteDC(hdcMemDC);
      ReleaseDC(hwndTarget, hdcWindow);
      return;
    }
    SelectObject(hdcMemDC, hbmScreen);
    if (!BitBlt(hdcMemDC, 0, 0, (*width), (*height), hdcWindow, 0, 0, SRCCOPY)) {
      return;
    }
    BITMAPINFO bmpInfo;
    bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmpInfo.bmiHeader.biWidth = (*width);
    bmpInfo.bmiHeader.biHeight = -(*height);
    bmpInfo.bmiHeader.biPlanes = 1;
    bmpInfo.bmiHeader.biBitCount = 24;
    bmpInfo.bmiHeader.biCompression = BI_RGB;
    std::vector<unsigned char> src((*width) * (*height) * 3);
    if (!GetDIBits(hdcMemDC, hbmScreen, 0, (*height), src.data(), &bmpInfo, DIB_RGB_COLORS)) {
      return;
    }
    RgbToRgba(src.data(), pixels, (*width), (*height));
    DeleteObject(hbmScreen);
    DeleteDC(hdcMemDC);
    ReleaseDC(hwndTarget, hdcWindow);
  }
}
#endif

} // anonymous namespace

namespace libwincapture {

int capture_add(window_t window) {
  index++;
  capture_window[index] = window;
  #if defined(_WIN32)
  CaptureWindow(index, (HWND)(void *)window, nullptr, &capture_width[index], &capture_height[index]);
  #elif (defined(__APPLE__) && defined(__MACH__))
  #elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
  #endif
  return index;
}

bool capture_exists(int ind) {
  if (capture_window.find(ind) == capture_window.end()) return false;
  return true;
}

bool capture_delete(int ind) {
  if (!capture_exists(ind)) return false;
  capture_cursor.erase(ind);
  capture_window.erase(ind);
  capture_width.erase(ind);
  capture_height.erase(ind);
  return true;
}

bool capture_get_showcursor(int ind) {
  if (!capture_exists(ind)) return false;
  return capture_cursor[ind];
}

bool capture_set_showcursor(int ind, bool show) {
  if (!capture_exists(ind)) return false;
  capture_cursor[ind] = show;
  return true;
}

int capture_get_width(int ind) {
  if (!capture_exists(ind)) return -1;
  return capture_width.find(ind)->second;
}

int capture_get_height(int ind) {
  if (!capture_exists(ind)) return -1;
  return capture_height.find(ind)->second;
}

bool capture_grab_frame_buffer(int ind, unsigned char *buffer) {
  if (!capture_exists(ind)) return false;
  #if defined(_WIN32)
  HWND hwnd = (HWND)(void *)capture_window.find(ind)->second;
  unsigned char *pixels = buffer;
  CaptureWindow(index, hwnd, &pixels, &capture_width[ind], &capture_height[ind]);
  #elif (defined(__APPLE__) && defined(__MACH__))
  #elif ((defined(__linux__) && !defined(__ANDROID__)) || defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sun))
  #endif
  return true;
}

} // namespace libwincapture

