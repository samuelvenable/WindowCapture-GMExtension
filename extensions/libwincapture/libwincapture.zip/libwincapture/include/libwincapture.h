#include <string>

typedef void *window_t;
typedef std::string wid_t;

namespace libwincapture {

  int capture_add(window_t window);
  bool capture_exists(int ind);
  bool capture_delete(int ind);
  int capture_get_width(int ind);
  int capture_get_height(int ind);
  bool capture_grab_frame_buffer(int ind, void *buffer);
  bool capture_update(int ind);
  int capture_create_window_list();
  bool capture_window_list_exists(int list);
  wid_t capture_get_window_id(int list, int ind);
  int capture_get_window_id_length(int list);
  bool capture_destroy_window_list(int list);
  std::string capture_get_window_caption(wid_t window);
  bool capture_get_fixedsize(int ind);
  bool capture_set_fixedsize(int ind, bool fixed);

} // namespace libwincapture