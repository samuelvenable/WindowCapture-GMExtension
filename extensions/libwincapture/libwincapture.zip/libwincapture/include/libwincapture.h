#define window_t char *

namespace libwincapture {

int capture_add(window_t window);
bool capture_exists(int ind);
bool capture_delete(int ind);
bool capture_get_showcursor(int ind);
bool capture_set_showcursor(int ind, bool show);
int capture_get_width(int ind);
int capture_get_height(int ind);
bool capture_grab_frame_buffer(int ind, unsigned char *buffer);

} // namespace libwincapture
