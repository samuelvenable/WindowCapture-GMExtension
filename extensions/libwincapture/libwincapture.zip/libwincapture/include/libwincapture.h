#define window_t char *

namespace libwincapture {

int capture_add(window_t window);
bool capture_exists(int ind);
bool capture_delete(int ind);
int capture_get_width(int ind);
int capture_get_height(int ind);
bool capture_grab_frame_buffer(int ind, unsigned char *buffer);
bool capture_update(int ind);
int capture_create_window_list();
window_t capture_get_window_id(int list, int ind);
int capture_get_window_id_length(int list);
bool capture_destroy_window_list(int list);
char *capture_get_window_caption(window_t window);
bool capture_get_fixedsize(int ind);
bool capture_set_fixedsize(int ind, bool fixed);

} // namespace libwincapture
